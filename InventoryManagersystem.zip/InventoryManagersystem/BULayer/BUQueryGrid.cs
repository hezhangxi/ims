﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using DALayer;


namespace BULayer
{
    public class BUQueryGrid
    {
        DAQueryGrid myDAQueryGrid = new DAQueryGrid();
         #region  public DataTable GetInfo(string paramUserName, string paramPhone) 获取数据
       /// <summary>
       /// 获取数据
       /// </summary>
       /// <param name="paramUserName"></param>
       /// <param name="paramPhone"></param>
       /// <returns></returns>
        public DataTable GetInfo(string paramUserName, string paramPhone)
        {
            return myDAQueryGrid.GetInfo(paramUserName,  paramPhone);
        }
        #endregion
    }
}
