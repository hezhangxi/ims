﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DALayer;
using System.Data;
using System.Data.SqlClient;



namespace BULayer
{
    public class BUCheckResult
    {
        Sqlconn mySqlconn = new Sqlconn();
        
       
        
        public int CheckInput(string paramUsename,string paramPasswd,string paramTelephone,string paramEmail,string paramAddress)
        {
            int ReturnValue = 0;
            string strSQL = @" insert into adminuser  (username,passwd,telephone,email,address)
values('"+paramUsename+" ','"+paramPasswd+"','"+paramTelephone+"','"+paramEmail+"','"+paramAddress+"')";
            ReturnValue = mySqlconn.ReturnRowsLine(strSQL);
            return ReturnValue;

        }
        public int CheckUserModify(string paramUsename,string paramTelephone,string paramEmail,string paramAddress)
        {
            int ReturnValue = 0;
            string strSQL = " update adminuser set telephone = '"+paramTelephone+"' ,[address] = '"+paramAddress+"',email = '"+paramEmail+"'where username = '"+paramUsename+"' ";
            ReturnValue = mySqlconn.ReturnRowsLine(strSQL);
            return ReturnValue;

        }

        public DataTable GetCustomerDt(string paramUserName)
        {
            DataSet myDs = new DataSet();
            DataTable myDt = new DataTable();
            Sqlconn mySqlconn = new Sqlconn();

            string SQL = "Select username ,telephone,address,email from adminuser Where 1=1 ";

            if (paramUserName.Length > 0)
            {
                SQL += " and  UserID='" + paramUserName + "'";
            }
            myDs = mySqlconn.Query(SQL);
            if (myDs.Tables.Count == 0 || myDs.Tables[0].Rows.Count == 0)
            {
                //MessageBox.Show("暂无数据");
                return myDt;
            }
            myDt = myDs.Tables[0];
            return myDt;
        }

        public bool DelData(string userName)
        {
            int ReturnValue = 0;
            string strSql = "delete  from adminuser where username = '" + userName + "'";

            ReturnValue = mySqlconn.ExeNonQuery(strSql); ;

            if (ReturnValue > 0)
            {
                return true;
            }
            else
            {
                return false;
            }

        }




    }
}
