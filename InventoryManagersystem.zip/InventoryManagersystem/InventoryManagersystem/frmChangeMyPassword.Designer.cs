﻿namespace InventoryManagersystem
{
    partial class frmChangeMyPassword
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtBoxMyName = new System.Windows.Forms.TextBox();
            this.lblUsername = new System.Windows.Forms.Label();
            this.txtBoxMyPassWord = new System.Windows.Forms.TextBox();
            this.lblNowPassWord = new System.Windows.Forms.Label();
            this.txtBoxNewPassWord = new System.Windows.Forms.TextBox();
            this.lblNewPassWord = new System.Windows.Forms.Label();
            this.btnOK = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.txtBoxConfirm = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtBoxMyName
            // 
            this.txtBoxMyName.Location = new System.Drawing.Point(98, 32);
            this.txtBoxMyName.Name = "txtBoxMyName";
            this.txtBoxMyName.ReadOnly = true;
            this.txtBoxMyName.Size = new System.Drawing.Size(148, 21);
            this.txtBoxMyName.TabIndex = 10;
            // 
            // lblUsername
            // 
            this.lblUsername.AutoSize = true;
            this.lblUsername.Location = new System.Drawing.Point(24, 35);
            this.lblUsername.Name = "lblUsername";
            this.lblUsername.Size = new System.Drawing.Size(53, 12);
            this.lblUsername.TabIndex = 1;
            this.lblUsername.Text = "当前用户";
            // 
            // txtBoxMyPassWord
            // 
            this.txtBoxMyPassWord.Location = new System.Drawing.Point(98, 59);
            this.txtBoxMyPassWord.Name = "txtBoxMyPassWord";
            this.txtBoxMyPassWord.Size = new System.Drawing.Size(148, 21);
            this.txtBoxMyPassWord.TabIndex = 1;
            this.txtBoxMyPassWord.UseSystemPasswordChar = true;
            this.txtBoxMyPassWord.TextChanged += new System.EventHandler(this.txtBoxMyPassWord_TextChanged);
            // 
            // lblNowPassWord
            // 
            this.lblNowPassWord.AutoSize = true;
            this.lblNowPassWord.Location = new System.Drawing.Point(24, 62);
            this.lblNowPassWord.Name = "lblNowPassWord";
            this.lblNowPassWord.Size = new System.Drawing.Size(53, 12);
            this.lblNowPassWord.TabIndex = 1;
            this.lblNowPassWord.Text = "当前密码";
            // 
            // txtBoxNewPassWord
            // 
            this.txtBoxNewPassWord.Location = new System.Drawing.Point(98, 86);
            this.txtBoxNewPassWord.Name = "txtBoxNewPassWord";
            this.txtBoxNewPassWord.Size = new System.Drawing.Size(148, 21);
            this.txtBoxNewPassWord.TabIndex = 2;
            this.txtBoxNewPassWord.UseSystemPasswordChar = true;
            // 
            // lblNewPassWord
            // 
            this.lblNewPassWord.AutoSize = true;
            this.lblNewPassWord.Location = new System.Drawing.Point(24, 89);
            this.lblNewPassWord.Name = "lblNewPassWord";
            this.lblNewPassWord.Size = new System.Drawing.Size(53, 12);
            this.lblNewPassWord.TabIndex = 1;
            this.lblNewPassWord.Text = "新 密 码";
            // 
            // btnOK
            // 
            this.btnOK.Location = new System.Drawing.Point(61, 149);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(75, 23);
            this.btnOK.TabIndex = 4;
            this.btnOK.Text = "确认";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(142, 149);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 5;
            this.btnCancel.Text = "取消";
            this.btnCancel.UseVisualStyleBackColor = true;
            // 
            // txtBoxConfirm
            // 
            this.txtBoxConfirm.Location = new System.Drawing.Point(98, 113);
            this.txtBoxConfirm.Name = "txtBoxConfirm";
            this.txtBoxConfirm.Size = new System.Drawing.Size(148, 21);
            this.txtBoxConfirm.TabIndex = 3;
            this.txtBoxConfirm.UseSystemPasswordChar = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(24, 116);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 1;
            this.label1.Text = "确认密码";
            // 
            // frmChangeMyPassword
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 193);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblNewPassWord);
            this.Controls.Add(this.lblNowPassWord);
            this.Controls.Add(this.lblUsername);
            this.Controls.Add(this.txtBoxConfirm);
            this.Controls.Add(this.txtBoxNewPassWord);
            this.Controls.Add(this.txtBoxMyPassWord);
            this.Controls.Add(this.txtBoxMyName);
            this.Name = "frmChangeMyPassword";
            this.Text = "修改密码";
            this.Load += new System.EventHandler(this.frmChangeMyPassword_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtBoxMyName;
        private System.Windows.Forms.Label lblUsername;
        private System.Windows.Forms.TextBox txtBoxMyPassWord;
        private System.Windows.Forms.Label lblNowPassWord;
        private System.Windows.Forms.TextBox txtBoxNewPassWord;
        private System.Windows.Forms.Label lblNewPassWord;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.TextBox txtBoxConfirm;
        private System.Windows.Forms.Label label1;
    }
}