﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;


namespace InventoryManagersystem
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
        }

       

   
      /// <summary>
      /// 通过用户名文本框判读
      /// </summary>
      /// <param name="paramTxtUserName">用户名文本框</param>
      /// <returns></returns>
        public bool CheckIput(string paramTxtUserName)
        {
            bool RetuenValue = false;

            if (paramTxtUserName.Length == 0)
            {
                RetuenValue = true;

            }

            return RetuenValue;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string userName = this.textBox1.Text;
            string passWord = this.textBox2.Text;
            string strLabErr = "";
         
     


           string sqlQuery = "select * from adminuser where username = '"+userName+"'";
           string sqlQuery2 = "select * from adminuser where passwd = '" + passWord + "'";
            DataSet myds = new DataSet(); //实例化DataSet类 为myds
            Sqlconn mySqlConn = new Sqlconn(); //实例化自建的Sqlconn类为mySqlConn
            myds = mySqlConn.Query(sqlQuery); //使用mySqlConn类下的Query方法
            string usrNum = mySqlConn.ExecuteSql(sqlQuery);

            if (usrNum.Length>0)
            {
                myds = mySqlConn.Query(sqlQuery);
               // string pwdNum = mySqlConn.ExecuteSql(sqlQuery2);
                string pwdNum = myds.Tables[0].Rows[0]["passwd"].ToString().Trim();
                if (pwdNum == passWord)
                {
                    this.labShowPwdErr.Text = "";
                   // MessageBox.Show("登陆成功", "登陆", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Hide();//隐藏
                    Frmmain myFrmmain = new Frmmain();
                    myFrmmain.ShowDialog();//模式窗体
                }
                else
                {
                    strLabErr = "密码错误，请重新输入";
                   // MessageBox.Show("密码错误，请重新输入", "登陆失败", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    this.labShowPwdErr.Text = strLabErr;
                }


          
            }
            else
            {
               // MessageBox.Show("用户名错误，请输入正确用户名", "登陆失败", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.labShowPwdErr.Text = "用户名错误，请输入正确用户名";

            }
     



            

            //if (usrNum > 0 && pwdNum > 0)
            //{
            //    MessageBox.Show("登陆成功", "登陆",MessageBoxButtons.OK,MessageBoxIcon.Information);
            //}
            //else
            //{
            //    MessageBox.Show("用户名或密码错误，请重新输入","登陆失败",MessageBoxButtons.OK,MessageBoxIcon.Information);
            //}

            //int num = myds.Tables[0].Rows.Count;

            //MessageBox.Show(num.ToString());
    
            //MessageBox.Show("密码为" + myds.Tables[0].Rows[0]["passwd"]);






            //string userName = this.textBox1.Text;
            //string passWord = this.textBox2.Text;
            //if (CheckIput(userName))
            //{
            //    MessageBox.Show("用户名不能为空！");
            //    textBox1.Focus();
            //    textBox1.SelectAll();
            //    return;
            //}

  
            //if (userName.Equals("admin") && passWord.Equals("123"))
            //{
            //    MessageBox.Show("欢迎登陆进销存系统","登陆成功",MessageBoxButtons.OK,MessageBoxIcon.Information);

            //}
            //else
            //{
            //    MessageBox.Show("您输入的用户名或密码错误","登陆失败！",MessageBoxButtons.OK,MessageBoxIcon.Information);






            //}
        }

        private void textBox2_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                button1_Click(sender, e);
            }
        }

    
        

        //private void btn_Cancle_Click(object sender, EventArgs e)
        //{
        //    textBox1.Text = "";
        //    textBox2.Text = "";
        //    textBox1.Focus();


        //}
       

       
    }
}
