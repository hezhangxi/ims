﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using BULayer;

namespace InventoryManagersystem
{
    public partial class QueryGrid : Form
    {
        public QueryGrid()
        {
            InitializeComponent();
        }

        BUQueryGrid myBUQueryGrid = new BUQueryGrid();//调用BU层

        

        private void button1_Click(object sender, EventArgs e)
        {
            string userName = this.textBox1.Text;
            string telePhone = this.textBox2.Text;
            this.dataGridView1.DataSource = myBUQueryGrid.GetInfo(userName, telePhone);
 
        }

        private void QueryGrid_Load(object sender, EventArgs e)
        {

        }

     
    }
}
